package oop.lab.lab11.factorymethod.demo;

public interface Fruit {
    void produceJuice();
}

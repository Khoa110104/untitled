package oop.lab.lab11.factorymethod.demo;

public class Banana implements Fruit {
    public void produceJuice() {
        System.out.println("Banana");
    }
}
package oop.lab.lab11.factorymethod.example;

public class TPBank implements Bank {
    @Override
    public String getBankName() {
        return "TPBank";
    }
}

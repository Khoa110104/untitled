package oop.lab.lab11.factorymethod.example;

public interface Bank {
    String getBankName();
}

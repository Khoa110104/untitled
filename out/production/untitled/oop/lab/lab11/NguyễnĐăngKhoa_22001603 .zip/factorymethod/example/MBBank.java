package oop.lab.lab11.factorymethod.example;

public class MBBank implements Bank {
    @Override
    public String getBankName() {
        return "MBBank";
    }
}

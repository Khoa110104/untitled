package oop.lab.lab11.factorymethod.demo;

public class Apple implements Fruit {
    public void produceJuice() {
        System.out.println("Apple");
    }
}
package oop.lab.lab11.iterator.example;

public interface Iterator {
    public boolean hasNext();
    public Object next();
}
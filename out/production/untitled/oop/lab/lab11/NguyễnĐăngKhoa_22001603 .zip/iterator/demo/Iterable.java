package oop.lab.lab11.iterator.demo;

public interface Iterable {
    Iterator getIterator();
}

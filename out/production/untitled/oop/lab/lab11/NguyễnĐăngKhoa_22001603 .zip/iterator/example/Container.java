package oop.lab.lab11.iterator.example;

public interface Container {
    public Iterator getIterator();
}
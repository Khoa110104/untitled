package oop.lab.lab11.iterator.demo;

public interface Iterator {
    boolean hasNext();

    Object next();
}

package oop.lab.lab11.iterator.pseudocode;

public interface ProfileIterator {
    boolean hasMore();

    Profile getNext();
}
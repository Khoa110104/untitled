//package oop.lab.lab11.visitor.pseudocode;
//
//
//public class XMLExportVisitor implements Visitor {
//
//    @Override
//    public void visitDot(Dot dot) {
//        System.out.println(
//                "Exporting Dot ID and coordinates: ID: " + dot.getId() + ", x:" + dot.getX() + ", y:" + dot.getY());
//    }
//
//    @Override
//    public void visitRectangle(Rectangle rect) {
//        System.out.println("Exporting Dot ID and coordinates: ID: " + rect.getId() + ", x:" + rect.getX() + ", y:" + rect.getY());
//    }
//
//    @Override
//    public void visitCompoundShape(CompoundShape cs){
//
//}
//
//
////    @Override
//    public void visitCircle(Circle circle) {
//        System.out.println("Exporting Dot ID and coordinates: ID: " + circle.getId() + ", x:" + circle.getX() + ", y:" + circle.getY());
//    }
//
//}
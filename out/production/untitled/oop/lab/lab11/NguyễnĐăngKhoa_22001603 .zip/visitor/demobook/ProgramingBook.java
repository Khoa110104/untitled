package oop.lab.lab11.visitor.demobook;

public interface ProgramingBook extends Book {

    String getResource();
}
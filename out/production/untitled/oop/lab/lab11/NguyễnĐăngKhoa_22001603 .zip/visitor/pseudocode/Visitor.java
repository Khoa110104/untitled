//package oop.lab.lab11.visitor.pseudocode;
//
//public interface Visitor {
//    void visitDot(Dot d);
//    void visitCircle(Circle c);
//    void visitRectangle(Rectangle r);
//    String visitCompoundShape(CompoundShape cs);
//}
//

package oop.lab.lab11.abstractfactory.example;


public interface ComputerAbstractFactory {

    Computer createComputer();

}
package oop.lab.lab11.abstractfactory.demo;

public abstract class AbstractFactory {
    abstract Shape getShape(ShapeType shapeType);
}
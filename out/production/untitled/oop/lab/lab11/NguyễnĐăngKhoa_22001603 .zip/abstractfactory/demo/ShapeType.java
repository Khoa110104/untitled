package oop.lab.lab11.abstractfactory.demo;

public enum ShapeType {
    RECTANGLE, SQUARE
}

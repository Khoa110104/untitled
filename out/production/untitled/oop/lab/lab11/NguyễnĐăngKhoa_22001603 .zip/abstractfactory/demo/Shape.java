package oop.lab.lab11.abstractfactory.demo;

public interface Shape {
    void draw();
}
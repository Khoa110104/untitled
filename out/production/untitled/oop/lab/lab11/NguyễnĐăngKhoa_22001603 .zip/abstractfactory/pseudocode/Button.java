package oop.lab.lab11.abstractfactory.pseudocode;

public interface Button {
    void paint();
}

package oop.lab.lab11.abstractfactory.demo;

public class RoundedSquare implements Shape {
    @Override
    public void draw() {
        System.out.println("Draw RoundedSquare");
    }
}

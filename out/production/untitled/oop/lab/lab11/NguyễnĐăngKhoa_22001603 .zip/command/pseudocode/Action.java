package oop.lab.lab11.command.pseudocode;

public interface Action {
    void perform();
}

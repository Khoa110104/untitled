package oop.lab.lab11.command.demo;

public class Computer {
    public void shutDown() {
        System.out.println("Computer is shutdown");
    }

    public void restart() {
        System.out.println("Computer is restart");
    }
}

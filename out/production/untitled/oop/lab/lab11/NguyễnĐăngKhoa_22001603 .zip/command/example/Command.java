package oop.lab.lab11.command.example;

public interface Command {

    void execute();
}
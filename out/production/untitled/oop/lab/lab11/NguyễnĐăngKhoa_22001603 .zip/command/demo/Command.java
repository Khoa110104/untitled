package oop.lab.lab11.command.demo;

 public interface Command {
     void execute();
 }
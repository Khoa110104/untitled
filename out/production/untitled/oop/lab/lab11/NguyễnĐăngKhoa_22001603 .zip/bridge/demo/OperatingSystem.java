package oop.lab.lab11.bridge.demo;

public interface OperatingSystem {
    void startup();

    void loadUrl(String url);
}
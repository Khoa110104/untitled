package oop.midterm2023.properties.polymorphism;

/* Tính đa hình cho phép các đối tượng có thể có nhiều hình dạng hoặc cách thức hoạt động khác nhau,tùy thuộc vào ngữ
   cảnh mà chúng được sử dụng.Ví dụ về tính đa hình trong Java là sử dụng phương thức ghi đè (method overriding).
   Phương thức ghi đè cho phép một lớp con định nghĩa lại một phương thức được định nghĩa trong lớp cha, và sử dụng
   chức năng khác nhau tùy thuộc vào lớp con đó.
*/

public class TestMain {
    public static void main(String[] args) {
/* Trong ví dụ này lớp Shape định nghĩa một phương thức getArea() tính diện trả về giá trị. Lớp con Circle và Rectangle
kế thừa từ lớp Shape và định nghĩa lại phương thức makeSound theo cách khác nhau và in ra kết quả khác nhau.
 */
        Shape shape;
        shape = new Circle(2);
        System.out.println("area is: " + shape.getArea());
        // Đối tượng shape ra đã định nghĩa lại phương thức getArea() tính diện tích theo lớp con Circle

        shape = new Rectangle(3, 4);
        System.out.println("area is: " + shape.getArea());
        // Đối tượng shape ra đã định nghĩa lại phương thức getArea() tính diện tích theo lớp con Rectangle
    }
}

package oop.midterm2023.properties.polymorphism;

public class Shape {
    public double getArea() {
        return 0;
    }
}

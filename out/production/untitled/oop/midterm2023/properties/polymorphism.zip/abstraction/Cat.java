package oop.midterm2023.properties.abstraction;

public class Cat extends Animal {

    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}

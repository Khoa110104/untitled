package oop.midterm2023.properties.abstraction;

public class Dog extends Animal {
    @Override
    public void greeting() {
        System.out.println("Woof!");
    }
}

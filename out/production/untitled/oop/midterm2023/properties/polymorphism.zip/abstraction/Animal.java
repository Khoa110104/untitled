package oop.midterm2023.properties.abstraction;

abstract public class Animal {
    abstract public void greeting();
}

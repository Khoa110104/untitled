package hw7_22001603_NguyenDangKhoa.combo2.ex2;

public interface BinarySearchTreeInterface {
   Node root();
    int size();
    boolean isEmpty();
    Node parent(Node p);
    Node left(Node p);
    Node right(Node p);
}

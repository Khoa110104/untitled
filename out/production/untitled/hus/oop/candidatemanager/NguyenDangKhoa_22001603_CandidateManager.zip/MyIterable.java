package hus.oop.candidatemanager;

public interface MyIterable {
    MyIterator iterator();
}

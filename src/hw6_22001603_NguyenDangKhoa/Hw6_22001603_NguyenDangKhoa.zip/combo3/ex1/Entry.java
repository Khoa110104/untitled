package hw6_22001603_NguyenDangKhoa.combo3.ex1;

public interface Entry<K,E> {
    K getKey();
    E getValue();

}

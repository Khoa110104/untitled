package hw6_22001603_NguyenDangKhoa.combo3.ex6;

public class TestMain {
    public static void main(String[] args) {
        StockTradingSystem tradingSystem = new StockTradingSystem();
        tradingSystem.processCommand();
    }
}

package oop.lab.lab7.ex1_5;

public interface GeometricObject {
    double getPerimeter();

    double getArea();

}

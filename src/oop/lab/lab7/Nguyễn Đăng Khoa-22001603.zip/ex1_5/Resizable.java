package oop.lab.lab7.ex1_5;

public interface Resizable {
    void resize(int percent);
}

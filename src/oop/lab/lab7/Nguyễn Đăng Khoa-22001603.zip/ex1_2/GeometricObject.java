package oop.lab.lab7.ex1_2;

public interface GeometricObject {
    double getArea();

    double getPerimeter();
}

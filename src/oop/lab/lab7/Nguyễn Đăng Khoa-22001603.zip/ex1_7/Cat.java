package oop.lab.lab7.ex1_7;

public class Cat extends Animal {

    @Override
    public void greeting() {
        System.out.println("Meow!");
    }
}

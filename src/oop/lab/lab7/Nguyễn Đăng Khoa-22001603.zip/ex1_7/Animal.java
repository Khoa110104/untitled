package oop.lab.lab7.ex1_7;

abstract public class Animal {
    abstract public void greeting();
}

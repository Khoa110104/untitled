package oop.lab.lab7.ex1_7;

public class TestMain {
    public static void main(String[] args) {

    }
}

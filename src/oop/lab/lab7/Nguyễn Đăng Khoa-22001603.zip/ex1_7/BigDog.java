package oop.lab.lab7.ex1_7;

public class BigDog extends Dog {
    public void greeting() {
        System.out.println("Woof!");
    }

    public void greeting(Dog another) {
        System.out.println("Woooooowwwww!");
    }
}

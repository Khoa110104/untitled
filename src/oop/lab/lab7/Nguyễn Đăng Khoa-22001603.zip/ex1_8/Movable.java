package oop.lab.lab7.ex1_8;

public interface Movable {
    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();

}

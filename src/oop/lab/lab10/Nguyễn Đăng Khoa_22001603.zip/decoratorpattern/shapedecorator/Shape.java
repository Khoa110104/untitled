package oop.lab.lab10.decoratorpattern.shapedecorator;

public interface Shape {
    void draw();
}

package oop.lab.lab10.decoratorpattern.example;

public abstract class MilkTea  {
    String description = "MileTea";
    public String getDescription() {
        return description;
    }
    public abstract double cost();
}


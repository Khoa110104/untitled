package oop.lab.lab10.decoratorpattern.icecreamdecorator;

public interface IceCream {
    String description = "IceCream";

    String getDescription();
}

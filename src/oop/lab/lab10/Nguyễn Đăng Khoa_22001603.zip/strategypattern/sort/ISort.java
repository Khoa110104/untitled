package oop.lab.lab10.strategypattern.sort;

public interface ISort {
    int sort(int[] data);
}

package oop.lab.lab10.strategypattern.pseudocode;

public interface Strategy {
    long execute(long a, long b);
}

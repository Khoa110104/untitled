package oop.lab.lab10.strategypattern.example;

public interface PromoteStrategy {
    double doDiscount(double price);
}

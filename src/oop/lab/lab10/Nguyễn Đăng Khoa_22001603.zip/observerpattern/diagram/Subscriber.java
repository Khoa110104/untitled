package oop.lab.lab10.observerpattern.diagram;


public interface Subscriber {
    void update(int data);
}

package oop.lab.lab10.observerpattern.pseudocode;

public interface EventListener {
    void update(String filename);
}


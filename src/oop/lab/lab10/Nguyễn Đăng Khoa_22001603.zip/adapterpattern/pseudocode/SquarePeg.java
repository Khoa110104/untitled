package oop.lab.lab10.adapterpattern.pseudocode;

public class SquarePeg {
    private double width;

    public SquarePeg(int width) {
        this.width = width;
    }

    public double getWidth() {
        return width;
    }
}

package oop.lab.lab10.adapterpattern.example;

public interface SocketAdapter {
    public Volt get240Volt();

    public Volt get24Volt();

    public Volt get6Volt();
}

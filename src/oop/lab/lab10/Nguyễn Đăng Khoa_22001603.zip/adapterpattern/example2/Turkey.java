package oop.lab.lab10.adapterpattern.example2;

public interface Turkey {

    void gobble();

    void fly();
}
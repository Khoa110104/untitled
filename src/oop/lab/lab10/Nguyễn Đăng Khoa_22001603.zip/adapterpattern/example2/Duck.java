package oop.lab.lab10.adapterpattern.example2;

public interface Duck {

    void quack();

    void fly();
}
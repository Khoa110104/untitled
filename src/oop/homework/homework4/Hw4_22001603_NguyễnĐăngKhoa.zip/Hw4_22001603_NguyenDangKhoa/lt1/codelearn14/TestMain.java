package Hw4_22001603_NguyenDangKhoa.lt1.codelearn14;

public class TestMain {
    public static void main(String[] args) {
        ToBinary toBinary = new ToBinary();
        System.out.print("3 to binary: ");
        toBinary.toBin(3);

        System.out.print("\n13 to binary: ");
        toBinary.toBin(13);

        System.out.print("\n10202 to binary: ");
        toBinary.toBin(10202);
    }
}
